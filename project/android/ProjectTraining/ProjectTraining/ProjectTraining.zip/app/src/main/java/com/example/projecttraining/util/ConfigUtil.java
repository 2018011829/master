package com.example.projecttraining.util;

public class ConfigUtil {
    //服务器地址
    public static final String SERVICE_ADDRESS="http://10.7.89.97:8080/tiantian/";
}
