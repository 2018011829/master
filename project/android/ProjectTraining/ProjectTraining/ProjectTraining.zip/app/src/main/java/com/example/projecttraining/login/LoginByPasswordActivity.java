package com.example.projecttraining.login;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.projecttraining.R;

public class LoginByPasswordActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_by_password);
    }
}
