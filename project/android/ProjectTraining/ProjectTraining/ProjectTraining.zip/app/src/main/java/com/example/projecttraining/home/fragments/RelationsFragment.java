package com.example.projecttraining.home.fragments;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.projecttraining.R;

/**
 * 联系人的fragment
 * @author 雨
 * @date 2020.11.21
 */
public class RelationsFragment extends Fragment {
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_relation,container,false);

        //TODO 得到控件引用

        //TODO 设置控件内容及点击事件

        return view;
    }
}
